import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());

// Mock Data
const candidates = [
  { id: 1, name: "Alice Johnson", skills: "JavaScript, React", experience: 5 },
  { id: 2, name: "Bob Smith", skills: "Python, Django", experience: 3 },
  { id: 3, name: "Charlie Brown", skills: "Java, Spring Boot", experience: 4 },
  { id: 4, name: "Dana White", skills: "C++, Qt", experience: 2 },
  { id: 5, name: "Evan Lee", skills: "Ruby, Rails", experience: 6 },
  { id: 6, name: "Fiona Kim", skills: "Go, Kubernetes", experience: 3 },
  { id: 7, name: "George Harris", skills: "PHP, Laravel", experience: 5 },
  { id: 8, name: "Helen Park", skills: "Swift, iOS", experience: 4 },
  { id: 9, name: "Ian Clark", skills: "Kotlin, Android", experience: 2 },
  { id: 10, name: "Julia Adams", skills: "HTML, CSS", experience: 1 },
];

// Endpoint
app.get('/api/candidates', (req, res) => {
  res.json(candidates);
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
