import React from "react";
import CandidateTable from "./components/CandidateTable";

function App() {
  return (
    <div>
      <CandidateTable />
    </div>
  );
}

export default App;
