import React, { useState, useEffect } from "react";
// import "./CandidateTable.css";

const CandidateTable = () => {
  const [candidates, setCandidates] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");

  useEffect(() => {
    fetch("http://localhost:5000/api/candidates")
      .then((response) => response.json())
      .then((data) => setCandidates(data))
      .catch((error) => console.error("Error fetching candidates:", error));
  }, []);

  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  const handleSort = () => {
    const sortedCandidates = [...candidates].sort((a, b) => {
      if (sortOrder === "asc") {
        return a.experience - b.experience;
      } else {
        return b.experience - a.experience;
      }
    });
    setCandidates(sortedCandidates);
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const filteredCandidates = candidates.filter(
    (candidate) =>
      candidate.name.toLowerCase().includes(searchQuery) ||
      candidate.skills.toLowerCase().includes(searchQuery)
  );

  return (
    <div>
      <h1>Candidate List</h1>
      <input
        type="text"
        placeholder="Search by name or skills"
        onChange={handleSearch}
      />
      <button onClick={handleSort}>
        Sort by Experience ({sortOrder === "asc" ? "Ascending" : "Descending"})
      </button>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Skills</th>
            <th>Years of Experience</th>
          </tr>
        </thead>
        <tbody>
          {filteredCandidates.map((candidate) => (
            <tr key={candidate.id}>
              <td>{candidate.name}</td>
              <td>{candidate.skills}</td>
              <td>{candidate.experience}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CandidateTable;
